關於 安裝 gerib10.mf 字體的説明

拷貝 gerib10.mf 以及 300dpi 360dpi 600dpi 720dpi 四個文件夾，

至 C:\texlive\texmf-local\fonts\source\genko 目錄下

管理員執行 mktexlsr 刷新即可。


_________________________________________________________________
子康
2019.9.28